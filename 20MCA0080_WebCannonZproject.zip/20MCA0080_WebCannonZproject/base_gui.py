from tkinter import *
import tkinter as tk
import pickle
import numpy as np

win = Tk()

def words_to_char(inputs):
    characters=[]
    for i in inputs:
        characters.append(i)
    return characters

def quit():
    global win
    win.destroy()

def filedreq():
    with open('model1_pickle','rb') as f:
        mp=pickle.load(f)
    with open('vectorise_pickle','rb') as f:
        vv=pickle.load(f)
    X_predict=np.array([predict.get()])
    X_predict=vv.transform(X_predict)
    result=mp.predict(X_predict)
    if predict.get() =="":
        print("password field is empty")
        user ="password field is empty"
        Label(win,text=user,fg="black",bg="red",font=("calibri 10 bold")).place(x=20,y=170)    
    elif result==2:
            print("password is strong")
            user ="password is strong"
            Label(win,text=user,fg="black",bg="red",font=("calibri 10 bold")).place(x=20,y=170)
    elif result==1:
        print("password is average")
        user ="password is average"
        Label(win,text=user,fg="black",bg="red",font=("calibri 10 bold")).place(x=20,y=170)
    else:
        print("password is weak")
        user ="password is weak"
        Label(win,text=user,fg="black",bg="red",font=("calibri 10 bold")).place(x=20,y=170)
win.geometry("500x300")
win.configure(background="light gray")
win.title("Web Cannon-Z")
title=Label(win,text="gimme some text!",width="300",height="2",fg="gray",font=("Calibri 20 bold")).pack()
predict=Label(win,text="Enter your text here",bg="light gray",font=("Calibri 16")).place(x=12,y=100)
predict=StringVar()
entry_predict= Entry(win,textvariable=predict,width="60")
entry_predict.place(x=20,y=150)




out=Button(win,text="cancel",width='12',height='1',activebackground="green",bg='gray',command=lambda win=win:quit(),font=("Calibri 12")).place(x=30,y=200)
submit=Button(win,text="submit",width='12',height='1',activebackground="green",bg='gray',command=filedreq,font=("Calibri 12")).place(x=250,y=200)

win.mainloop()